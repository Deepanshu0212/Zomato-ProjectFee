// var popup = document.getElementsByClassName("bigdiv")[0];
// document.addEventListener('mouseout', mouseEvent)

// // unction appearpopup(e){
// //     if (!e.toElement && !e.relatedTarget) {
// //         popup.classList.add('visible'); 
// //     }
// // }
//  const mouseEvent = e => {
//         if (!e.toElement && !e.relatedTarget) {
//          document.removeEventListener('mouseout', mouseEvent);
//  console.log="Hello";
//         popup.classList.add('visible');
//      }
//  };
//  function mouseEvdocument.removeEventListener('mouseout', mouseEvent);
//     // console.log="Hello";   
//     // document.getElementsByClassName("bigdiv").className="bigdiv visible";
// // }

// console.log(popup.className)

// let name=popup.className;
// console.log(let);


